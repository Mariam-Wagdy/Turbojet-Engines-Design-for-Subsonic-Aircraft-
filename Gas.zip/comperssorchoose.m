clear;
clc;
%INPUTS (Compressor Pressure Ratio Change)
M0 = .89;
T0 = 231.68; %(K)
p0=101325;

Fr=298893.2698;

gamma_c = 1.4;
gamma_t = 1.333;

Cp_c = 1004.5; %(J/kg.K)
Cp_t = 1148.86; %(J/kg.K)

Rc=287;
Rt=(gamma_t-1)*Cp_t/gamma_t;

a0 = sqrt(gamma_c*Rc*T0); %m/sec
V0 = a0*M0; %m/sec

hPR = 4.28*10^7; %(J/kg)


PI_d = 0.98;
PI_b=0.96;
PI_n = 0.96;%%%%%%%%%%%%%%
PI_c = 1:0.1:50;
Ec = 0.89;
Et = 0.91;
eita_b = 0.99;
eita_m = 0.99;

Pt9toP9_critical=((gamma_t+1)/2)^(gamma_t/(gamma_t-1));
Tt4 = T0:1:1170; %(K)
S_min=10^10;

specfic_thurst=NaN(length(PI_c),length(Tt4));
S=NaN(length(PI_c),length(Tt4));
thermaleffeciency=NaN(length(PI_c),length(Tt4));
propulsive_efficiency =NaN(length(PI_c),length(Tt4));
overall_eff=NaN(length(PI_c),length(Tt4));

Ac=1;
%%%%%%ram effect
taw_r = 1 + ((gamma_c - 1)/2)*M0^2;
PI_r = taw_r^(gamma_c/(gamma_c - 1));
u=1;

for i=1:length(PI_c)
    for j=1:length(Tt4)
        taw_c(i) = PI_c(i)^((gamma_c - 1)/(gamma_c*Ec));
        
        eita_c(i) = ((PI_c(i)^((gamma_c - 1)/gamma_c)) - 1)/(taw_c(i) - 1);
        
        taw_lambda(j) = (Cp_t*Tt4(j))/(Cp_c*T0) ;
        
        if (taw_lambda(j)<(taw_r*taw_c(i)) || taw_lambda(j)>((hPR*eita_b)/(Cp_c*T0)))
            taw_lambda(j)=NaN;
        end
        
        f(i,j) = (taw_lambda(j) - taw_r*taw_c(i))/((hPR*eita_b)/(Cp_c*T0) -taw_lambda(j));
        
        taw_t(i,j) = 1 - (taw_r/taw_lambda(j)*(taw_c(i) - 1))/(eita_m*(1 + f(i,j)));
        PI_t(i,j) = taw_t(i,j)^(gamma_t/((gamma_t - 1)*Et));
        eita_t(i,j) = (1 - taw_t(i,j))/(1 - (taw_t(i,j)^(1/Et)));
        
        Pt9toP0(i,j)=PI_r*PI_d*PI_b*PI_c(i)*PI_t(i,j)*PI_n;
         %%%%%%%%%%%%%unchocked%%%%%%%%%%%%%%%%%%
        if (Pt9toP0(i,j)< Pt9toP9_critical)
            Pt9toP9(i,j)=Pt9toP0(i,j);
            if((Pt9toP9(i,j))^((gamma_t -1)/gamma_t))<1
                Pt9toP9(i,j)=NaN;
                continue;
            end
            M9(i,j) = sqrt((2/(gamma_t - 1))*((Pt9toP9(i,j))^((gamma_t -1)/gamma_t) - 1));
            Tt7(i,j)=taw_t(i,j)*Tt4(j);
            V9(i,j)=sqrt(2*Cp_t*Tt7(i,j)*(1-(Pt9toP9(i,j))^(1/gamma_t-1)));
            
            V9e(i,j)=V9(i,j);
            specfic_thurst(i,j) =(1 + f(i,j))*V9e(i,j)-V0;
            %             if(specfic_thurst(i,j)<0)
            %                 specfic_thurst(i,j)=NaN;
            %                 continue
            %             end
            
            T9=Tt7(i,j)-V9(i,j)^2/(2*Cp_t);
            p9=p0;
            m_dot(i,j)=Fr/(4*specfic_thurst(i,j));
            A9(i,j)=m_dot(i,j)*(1+f(i,j))*Rt*T9/p9/V9(i,j); %%%%%%constant
            
            th_a(i,j)=4*specfic_thurst(i,j)*Ac*p9*V9(i,j)/(Rt*T9);
            if(th_a(i,j)>=Fr)
                %disp('yeyyy');
                %rec=i+"and"+j;
                %disp(rec);
                X(u)=i;
                Y(u)=j;
                u=u+1;
                %disp(m_dot(i,j));
            end
            
            S(i,j) = (f(i,j)/specfic_thurst(i,j)); %(Kg/sec)/N
             if (S(i,j)<0)
                S(i,j)=NaN;
                continue;
            end
            if (S(i,j)<S_min)
                S_min=S(i,j);
            end
            
            thermaleffeciency(i,j) = ((1 + f(i,j))*V9e(i,j)^2-V0^2)/(2*f(i,j)*hPR);
            propulsive_efficiency (i,j) = (2*V0*specfic_thurst(i,j))/((1 + f(i,j))*V9e(i,j)^2-V0^2);
            overall_eff(i,j) =propulsive_efficiency(i,j)*thermaleffeciency(i,j) ;
            
            
            %%%%%%%%%%%%%%%%%%%%chocked%%%%%%%%%%%%%%%%%%
        elseif (Pt9toP0(i,j)>= Pt9toP9_critical)
            P9toP0(i,j) = Pt9toP0(i,j) / Pt9toP9_critical;
            M9(i,j)=1;
            T9(i,j)=2*taw_t(i,j)*Tt4(j)/(1+gamma_t);
            V9(i,j)=sqrt(gamma_t*Rt*T9(i,j));
            V9e(i,j)=V9(i,j)*(1+(1-1/P9toP0(i,j))/gamma_t);
            specfic_thurst(i,j) =(1 + f(i,j))*V9e(i,j)-V0;
            
            
            m_dot(i,j)=Fr/(4*specfic_thurst(i,j));
            A9(i,j)=m_dot(i,j)*(1+f(i,j))*Rt*T9(i,j)/p9/V9(i,j); %%%%%%constant
            
            th_a(i,j)=4*specfic_thurst(i,j)*Ac*p9*V9(i,j)/(Rt*T9(i,j));
            if(th_a(i,j)>=Fr)
               %disp('bfffffffffffffff');
                X(u)=i;
                Y(u)=j;
                u=u+1;
                %rec=i+"and"+j;
                %disp(rec);
                %disp(m_dot(i,j));
            end
            
            
            
            S(i,j) = (f(i,j)/specfic_thurst(i,j)); %(Kg/sec)/N
            if (S(i,j)<0)
                S(i,j)=NaN;
                continue;
            end
            
            if (S(i,j)<S_min)
                S_min=S(i,j);
                row=i;
                column=j;
            end
            thermaleffeciency(i,j) = ((1 + f(i,j))*V9e(i,j)^2-V0^2)/(2*f(i,j)*hPR);
            propulsive_efficiency (i,j) = (2*V0*specfic_thurst(i,j))/((1 + f(i,j))*V9e(i,j)^2-V0^2);
            overall_eff(i,j) =propulsive_efficiency(i,j)*thermaleffeciency(i,j) ;
            
        end
    end
end



%OUTPUTS

figure (1)
plot(PI_c,specfic_thurst, 'Linewidth',2);
hold on
title("Specific Thrust vs. Compressor Pressure Ratio")
xlabel("Compressor Pressure Ratio")
ylabel("Specific Thrust N/(kg/s)")
legend('Mach = .89')

figure;
surf(Tt4,PI_c,real(specfic_thurst));
title("Specific Thrust vs. Compressor Pressure Ratio vs Tt4")




figure
plot(PI_c,S, 'Linewidth',2);
title("Specific Fuel Consumption vs. Compressor Pressure Ratio")
xlabel("Compressor Pressure Ratio")
ylabel("S (mg/N.s)")
legend('Mach = .89')



figure
surf(Tt4,PI_c,S);
title("Specific Fuel Consumption vs. Compressor Pressure Ratio vs Tt4")


figure
plot(PI_c,f, 'Linewidth',2);
title("Fuel/Air Ratio vs. Compressor Pressure Ratio")
xlabel("Compressor Pressure Ratio")
ylabel("f")
legend('Mach = .89')

figure
plot(PI_c,propulsive_efficiency, 'Linewidth',2);
title("P Efficiencies vs. Compressor Pressure Ratio")

figure
plot(PI_c,thermaleffeciency, 'Linewidth',2);
title("T Efficiencies vs. Compressor Pressure Ratio")

figure
plot(PI_c,overall_eff, 'Linewidth',2);
title("O Efficiencies vs. Compressor Pressure Ratio")
xlabel("Compressor Pressure Ratio")
ylabel("No Nt Np")
legend('Np','Nt','No')

minn=10^10;
%w=1:0.005:2;
%for o=1:length(w)
    for u=1:length(X)
        Ss(u)=S(X(u),Y(u));
    end
    
    M=sort(Ss);
    for k=1:121136
    out=M(k);
    result=find(abs(Ss-out) < 0.00000000000000001);
    I=X(result);
    J=Y(result);
    %minn=10^10;
%end

%plot(w,S(I,J));

% disp("indices are");
% disp(I);
% disp(J);

% e=" Minimum SFC in general: "+S_min; 
% disp(e);

p(k)=PI_c(I);
T(k)=Tt4(J);
m(k)=m_dot(I,J);
mach8(k)=M9(I,J);

if (k==1)
    e=" Compressor Pressure ratio: "+PI_c(I);
disp(e);
e=" Burner Exit Temperature: "+Tt4(J);
disp(e);
disp(" ");
e=" Minimum SFC: "+S(I,J); 
disp(e);
e=" Mass flow rate of air: "+m_dot(I,J); 
disp(e);
e=" Specific Thrust: "+specfic_thurst(I,J); 
disp(e); %(N/(kg/s))
e=" fule to air ratio "+f(I,J);
disp(e);
e=" Theraml Efficiency: "+thermaleffeciency(I,J);
disp(e);
e=" Propulsive Efficiency: "+propulsive_efficiency(I,J);
disp(e);
e=" Overall Efficiency: "+overall_eff(I,J);
disp( e);
e=" Compressor Isentropic efficiency: "+eita_c(I);
disp(e);
e=" Turbine Isentropic efficiency: "+eita_t(I,J);
disp(e);
e=" V9/V0: "+V9(I,J)/V0;
disp(e);
end

    end
    

